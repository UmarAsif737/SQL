CREATE DATABASE ProjLibrary
USE ProjLibrary

--users tables with created
CREATE TABLE Users(
id_user INT PRIMARY KEY IDENTITY(1,1),
name_user VARCHAR(30) NOT NULL,
);


--books table created having relationship with user with foreign key
CREATE TABLE Books (
id_book INT PRIMARY KEY IDENTITY(1,1),
name_book VARCHAR(30) NOT NULL,
price_book DECIMAL(18,1) NOT NULL,
shelfno_book INT,
category_book VARChAR(30),
id_user INT CONSTRAINT  user_fk FOREIGN KEY REFERENCES USERS(id_user)
);

--Inserting values to users table
INSERT INTO Users
VALUES 
('Rumi'),
('Hussain'),
('Hamza'),
('Mujahid'),
('Rauf');

--Inserting values to Books table
INSERT INTO Books 
VALUES 
('Alchemist',100,2,'fiction',1),
('KiteRunner',200,2,'fiction',1),
('Davinchi',300,2,'fiction',2),
('Astronomy',400,2,'fiction',NULL),
('Book5',400,2,'fiction',NULL);

--Adding two column in books table for the issue 
ALTER TABLE Books ADD issueDate DATE;

--setting issued date for issued books which were issued using hard coded data
UPDATE BOOKS SET issueDate='2022-10-13', id_user=1 WHERE id_book=1;
UPDATE BOOKS SET issueDate='2022-10-13', id_user=1 WHERE id_book=2;
UPDATE BOOKS SET issueDate='2022-5-13', id_user=2 WHERE id_book=3;

select * from Users;
select * from BOOKS;
