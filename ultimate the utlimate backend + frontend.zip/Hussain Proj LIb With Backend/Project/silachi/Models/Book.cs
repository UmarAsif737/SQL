﻿namespace silachi.Models
{
    public class Book
    {
        public int id { get; set; }
        public string? name { get; set; }
        public float? price { get; set; }
        public int? shelfNo { get; set; }
        public string? category { get; set; }
    }
}
