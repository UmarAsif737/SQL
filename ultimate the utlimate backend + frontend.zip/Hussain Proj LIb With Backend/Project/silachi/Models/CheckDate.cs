﻿using System;

namespace silachi.Models
{
    public class CheckDate
    {
        public string checkDate { get; set; }
    }
}
