﻿using System.Collections.Generic;

namespace silachi.Models
{
    public class User
    {
        public string name { get; set; }
        public int? id { get; set; }

        public List<Book> userbooks { get; set; }
    }
}
