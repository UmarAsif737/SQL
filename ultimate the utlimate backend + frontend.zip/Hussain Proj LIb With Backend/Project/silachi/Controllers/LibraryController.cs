﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using silachi.Business_Layer;
using silachi.Models;
using System;
using System.Linq;
using System.Collections.Generic;
using System.Runtime.InteropServices.WindowsRuntime;

namespace silachi.Controllers
{
    [Route("Library")]
    [ApiController]
    public class LibraryController : ControllerBase
    {

        ILibrary _Library;
        public LibraryController(ILibrary _Library)
        {
            this._Library = _Library;
        }

        // _______________________________URL for tasks___________________________________
        // library/getbookdetails/{name}
        // library/addbook
        // library/getuserdetails/{userId}
        // library/updatebook/{bookId}
        // library/updateuser/{userId}
        // library/issuebook/{userId}
        // library/deletebook/{bookName}
        // library/deleteuser/{userId}
        // library/returnbook/{bookId}
        // library/fine/{bookId}


        // ________________________________TASK 3__________________________________________
        // below api return details of books with its name
        [HttpGet("getbookdetails/{name}")]
        public IActionResult GetBookDetail(string name)
        {
           
            //  condition to check if book exists with this name
            if (_Library.GetBook(name).Count==0)
            {

                return NotFound("Enter the correct, book doesn't exist in system with this name");
            }
            else
            {
                return Ok(_Library.GetBook(name));
            }

        }

        // ________________________________TASK 1__________________________________________
        // below api add the book in the system and return list of books to show it was added in database

        [HttpPost("addbook")]

        public IActionResult BookAddition([FromBody] Book newbook)
        {
            // validation if user has input name empty value in the body
            // default value of price, shelf Numver and category will be assigned if not provided but name is compulsory
            if(newbook.name != "") 
            {
                return Ok(new { message = "book added Succesfully", books= _Library.AddBook(newbook) });
            }
            else
            {
                return BadRequest(new { message = "book was not added provide detail please proving name is compuslory" });
            }
        }

        // ________________________________TASK 2__________________________________________
        // Below api add new user in the data base


        [HttpPost("adduser")]

        public IActionResult UserAddition([FromBody] User user)
        {
            //  condition to check whether input is empty
           if(user.name != "")
            {
                
                return Ok(new {message="User added succesfully", AddedUser= from usr in _Library.AddUser(user) select new {userName=usr.name, userId=usr.id } });

            }
            else
            {
                return NotFound("user was not added atleast the name of user is compulsory");
            }
        }

        // ________________________________TASK 4__________________________________________
        // below api show get user detail based on its id

        [HttpGet("getuserdetails/{userId}")]
        public IActionResult GetUserDetail(int userId)
        {
          // condition to check the user for which details are required exists in the system
          if(_Library.GetUser(userId).id != null)
            {
                return Ok(_Library.GetUser(userId));
            }
            else
            {
                return NotFound("The User doesn't Exist with this id");
            }
            
       
                
        }

        // ________________________________TASK 5__________________________________________
        // below api used to update update the book

        [HttpPut("updatebook/{bookId}")]
        public IActionResult UpdatBook(int bookId, [FromBody] Book updatedBook)
        {
            updatedBook.id = bookId;
            Book checkInp = (from book in _Library.GetAllBooks() where book.id == bookId select book).FirstOrDefault();
            // condition to check whether the books which needs to be upated exists in the system
            if (checkInp == null)
            {
                return NotFound("book you want to update doesn't exist");
            }
            else
            {
                _Library.UpdateBook(updatedBook);
                Book updtBook = (from book in _Library.GetAllBooks() where book.id == bookId select book).FirstOrDefault();
                return Ok(new {afterUpdate= updtBook });
            }


       
        }

        // ________________________________TASK 6__________________________________________
        // below api is used to update the user details

        [HttpPut("updateuser/{userId}")]
        public IActionResult UpdateUser(int userId, [FromBody] User updatedUser)
        {
            updatedUser.id = userId;
            User check= _Library.GetUser(userId);
            // condition to check whether the user which needs to be upated exists in the system

            if (check.id == null)
            {
                return NotFound("The User doesn't Exist");
            }
            else
            {
                //  below function will update the user details
                _Library.UpdateUser(updatedUser);
                //  below function will show user detials after update
                User updtUser = _Library.GetUser(userId);

                return Ok(updtUser);
            }
            
           
            
          
        }

        // ________________________________TASK 7__________________________________________
        // below api is used to issue book

        [HttpPut("issuebook/{userId}")]
        public IActionResult IssueBook(int userId, [FromBody] Book issuedBook)
        {
            // Checking if the user is in the system
            var checkUser = (from user in _Library.GetAllUsers() where user.id == userId select user).FirstOrDefault();
            if(checkUser == null) { return NotFound("user with this userid doesn't exist in the system"); }

            // if no input id is given user will be asked to provide valid bookId
            // bookdId providing is compulsory for issuing book otherwise book wont be issued
            if (issuedBook.id == 0)
            {
                return BadRequest("Enter the valid book Id");
            }
            else { 
          
            var checkInIssued = (from book in _Library.GetIssuedBooks() where book.id == issuedBook.id select book).FirstOrDefault();
            var checkInSys = (from book in _Library.GetAllBooks() where book.id == issuedBook.id select book).FirstOrDefault();
                // Validation if the book with id exists in the system
                // Validation if the books is already Issued
                // Message for user is printed in both cases

                if (checkInSys == null)
                {
                    return NotFound("the book you want doesn't exist in the system");
                }
                else if (checkInIssued != null)
                {
                    return NotFound("book is already issued");

                }
                else
                {
                    return Ok(new { message = "book has been issues Succesfully", issuedBooksList = _Library.IssueBook(userId, issuedBook) });

                }

            }
        }

        // ________________________________TASK 8__________________________________________
        // below api is used to delete book from data base

        [HttpDelete("deletebook/{bookName}")]
        public IActionResult DeleteBook(string bookName)
        {
            var checkBook = (from book in _Library.GetAllBooks() where book.name.ToLower() == bookName.ToLower() select book).FirstOrDefault();
             // Condition to check whether book already doesn't exist in the system
            if (checkBook == null) { return NotFound("book with this book name doesn't exist in the system"); }
            else
            {
                _Library.DeleteBook(bookName);
                return Ok(new{ message= "Book deleted Succesfully",booksAfterDelete=_Library.GetAllBooks()});
            }
           

        }

        // ________________________________TASK 9__________________________________________
        // below api used to delete the user from data base

        [HttpDelete("deleteuser/{userId}")]
        public IActionResult DeleteUser(int userId)
        {
            var checkUser = (from user in _Library.GetAllUsers() where user.id == userId select user).FirstOrDefault();
            int countUsersBef = _Library.GetAllUsers().Count;

            // Condition to check whether user already doesn't exist in the system

            if (checkUser == null) { return NotFound("user with this userid doesn't exist in the system"); }
            else {
                _Library.DeleteUser(userId);
                int countUsersAft = _Library.GetAllUsers().Count;
                // condition to check if user was deleted from the data base
                // if user was  not deleted it means because he has not returned the books
                if (countUsersBef == countUsersAft)
                {
                    return Ok(new { message = "User have not returned book therefore can not be deleted", usersInSystem = from user in _Library.GetAllUsers() select new { userName = user.name, userId = user.id } });
                }
                else
                {
                    var usersAfter = from user in _Library.GetAllUsers() select new { userName = user.name, userId = user.id };
                   
                    return Ok(new { message = "User deleted Succesfully", usersAfterDelete = usersAfter });

                }

            }




        }

        // ________________________________TASK 10__________________________________________
        // below api is used to return the book to the library

        [HttpPut("returnbook/{bookId}")]
        public IActionResult ReturnBook(int bookId )
        {
            List<Book> issuedBooksBef = _Library.GetIssuedBooks();
            var checkInSys = (from book in _Library.GetAllBooks() where book.id == bookId select book).FirstOrDefault();
            var checkInIssued = (from book in _Library.GetIssuedBooks() where book.id == bookId select book).FirstOrDefault();
            
            // Condition to see it returned book belong to library by checking its existance in the system
            // also checked if book exists in the system but was not issued by user

            if (checkInSys == null) { return NotFound("The Book doesn't belong to Library"); }
            else if (checkInIssued==null) { return BadRequest("The book is not in the list of issued books"); }
            else
            {
                string fine=_Library.ReturnBook(bookId);
                List<Book> issuedBooksAft = _Library.GetIssuedBooks();
                return Ok(new {fine, bookIssuedListAfter = issuedBooksAft, bookIssuedListBefore = issuedBooksBef });

            }


        }

        // ________________________________TASK 11__________________________________________
        // below end point used to calculate the fine imposed on the user
        // data given in the body forexample date given as checkDate="2022-10-12"
        // if empty json assigned in the body fine will be calculated considering current as checkDate
        // 

        [HttpPut("fine/{bookId}")]
        public IActionResult CalculateFine(int bookId, [FromBody] CheckDate inputDate)
        {
            List<Book> issuedBooksBef = _Library.GetIssuedBooks();
            var checkInSys = (from book in _Library.GetAllBooks() where book.id == bookId select book).FirstOrDefault();
            var checkInIssued = (from book in _Library.GetIssuedBooks() where book.id == bookId select book).FirstOrDefault();
            // exception handling if date entered was wrong 
            try
            {
                // condition to check whether book exists or not in the system
                // if book exist and was issued then fine will be calculated
                if (checkInSys != null && checkInIssued != null)
                {
                    if (inputDate.checkDate != "")
                    {
                        DateTime date = Convert.ToDateTime(inputDate.checkDate);
                        return Ok(_Library.CalculateFine(bookId, date));
                    }
                    else
                    {
                        DateTime date = Convert.ToDateTime(DateTime.Now.ToString("yyyy/MM/dd"));
                        return Ok(_Library.CalculateFine(bookId, date));
                    }
                }
                // if book exists in the system but it was not issued below messsage will be return
                else if (checkInSys == null)
                {
                    return NotFound("The book doesn't exist in the system");
                }
                // if book doesn't exist in the system message will be return to user
                else
                {
                    return NotFound("The book was not issued");
                }

            }
            catch
            {
                return BadRequest("invalid date enter date in this format yyyy-mm-dd");
            }
        }



    }
}
