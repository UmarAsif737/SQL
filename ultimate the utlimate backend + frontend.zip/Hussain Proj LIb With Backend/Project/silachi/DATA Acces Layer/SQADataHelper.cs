﻿using Microsoft.Extensions.Configuration;
using silachi.Models;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System;
using System.Collections.Generic;
using System.Net;

namespace silachi.DATA_Acces_Layer
{
    public class SQADataHelper : ISQADataHelper
    {
        string connectionString = "";
        public SQADataHelper(IConfiguration config)
        {
            var c = config;
            connectionString = config.GetConnectionString("projectDB");
        }
        //task3
        public List<Book> GetBook(string name)
        {
            // multiple books are possible with same name that making list of those books
            List<Book> books = new List<Book>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_GetBookDetails", con);

                cmd.Parameters.Add("@name_book", SqlDbType.VarChar).Value = name;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    Book bookStore = new Book();


                    bookStore.id = Convert.ToInt32(sdr["id_book"]);
                    bookStore.name = sdr["name_book"].ToString();
                    bookStore.price = Convert.ToSingle(sdr["price_book"]);
                    bookStore.shelfNo = Convert.ToInt32(sdr["price_book"]);
                    bookStore.category = sdr["category_book"].ToString();

                    books.Add(bookStore);

                }
                con.Close();
            }
            return books;


        }
        //task1
        // ADD book in the library books
        public List<Book> AddBook(Book book)
        {
            List<Book> bookList = new List<Book>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_AddBook", con);
                SqlCommand cmd2 = new SqlCommand("sp_GetAllBooks", con);

                cmd.Parameters.Add("@name_book", SqlDbType.VarChar).Value = book.name;
                cmd.Parameters.Add("@price_book", SqlDbType.Decimal).Value = book.price;
                cmd.Parameters.Add("@shelfno_book", SqlDbType.Int).Value = book.shelfNo;
                cmd.Parameters.Add("@category_book", SqlDbType.VarChar).Value = book.category;





                cmd.CommandType = CommandType.StoredProcedure;
                cmd2.CommandType = CommandType.StoredProcedure;

                con.Open();
                cmd.ExecuteNonQuery();
                SqlDataReader sdr = cmd2.ExecuteReader();
                while (sdr.Read())
                {
                    Book bookStore = new Book();

                    bookStore.id = Convert.ToInt32(sdr["id_book"]);
                    bookStore.name = sdr["name_book"].ToString();
                    bookStore.price = Convert.ToSingle(sdr["price_book"]);
                    bookStore.shelfNo = Convert.ToInt32(sdr["shelfno_book"]);
                    bookStore.category = sdr["category_book"].ToString();


                    bookList.Add(bookStore);

                }

                con.Close();
                return bookList;

            }

        }

        //task2
        //add user to the db
        public List<User> AddUser(User user)
        {
            List<User> usersList = new List<User>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_AddTheUser", con);
                SqlCommand cmd2 = new SqlCommand("sp_GetAllUsers", con);

                cmd.Parameters.Add("@name_user", SqlDbType.VarChar).Value = user.name;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                SqlDataReader sdr = cmd2.ExecuteReader();
                while (sdr.Read())
                {
                    User userStore = new User();

                    userStore.id = Convert.ToInt32(sdr["id_user"]);
                    userStore.name = sdr["name_user"].ToString();
                    
                    usersList.Add(userStore);

                }
                con.Close();
                return usersList;

            }

        }

        //task4
        //Get user detail
        public User GetUser(int id)
        {
            User myuser = new User();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_GetUser", con);

                cmd.Parameters.Add("@id_user", SqlDbType.VarChar).Value = id;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {

                    myuser.id = Convert.ToInt32(sdr["id_user"]);
                    myuser.name = sdr["name_user"].ToString();




                }
                sdr.NextResult();
                List<Book> mybooks = new List<Book>();

                while (sdr.Read())
                {

                    Book book = new Book();
                    book.name = sdr["name_book"].ToString();
                    book.price = Convert.ToInt32(sdr["price_book"]);
                    book.id = Convert.ToInt32(sdr["id_book"]);
                    book.price = Convert.ToSingle(sdr["price_book"]);
                    book.shelfNo = Convert.ToInt32(sdr["shelfno_book"]);
                    book.category = sdr["category_book"].ToString();
                    mybooks.Add(book);

                }
                myuser.userbooks = mybooks;
                con.Close();
            }
            return myuser;


        }
        //task 5
        //update book
        public void UpdateBook(Book updatedBook)
        {


            //Book mybook = new Book();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_UpdateBook", con);

                cmd.Parameters.Add("@id_book", SqlDbType.Int).Value = updatedBook.id;
                if (updatedBook.name != null) { cmd.Parameters.Add("@name_book", SqlDbType.VarChar).Value = updatedBook.name; }
                else { cmd.Parameters.Add("@name_book", SqlDbType.VarChar).Value = (from book in GetAllBooks() where book.id == updatedBook.id select book.name).FirstOrDefault(); }
                
                if (updatedBook.price != null)
                { cmd.Parameters.Add("@price_book", SqlDbType.Decimal).Value = updatedBook.price; }
                else { cmd.Parameters.Add("@price_book", SqlDbType.Decimal).Value = (from book in GetAllBooks() where book.id == updatedBook.id select book.price).FirstOrDefault(); }

                if (updatedBook.shelfNo != null) { cmd.Parameters.Add("@shelfno_book", SqlDbType.Int).Value = updatedBook.shelfNo; }
                else { cmd.Parameters.Add("@shelfno_book", SqlDbType.Int).Value = (from book in GetAllBooks() where book.id == updatedBook.id select book.shelfNo).FirstOrDefault(); }
                
                if(updatedBook.category!=null) { cmd.Parameters.Add("@category_book", SqlDbType.VarChar).Value = updatedBook.category; }
                else { cmd.Parameters.Add("@category_book", SqlDbType.VarChar).Value = (from book in GetAllBooks() where book.id == updatedBook.id select book.category).FirstOrDefault(); }
                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }

            
        }

        //task 6
        //update book
        public void UpdateUser(User updatedUser)
        {


        
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_UpdateUser", con);

                cmd.Parameters.Add("@name_user", SqlDbType.VarChar).Value = updatedUser.name;
                cmd.Parameters.Add("@id_user", SqlDbType.Int).Value = updatedUser.id;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }

        
        }

        // Task 10 issuing book to user
        public List<string> IssueBook(int userID, Book issuedBook)
        {
            List<string> bookList = new List<string>();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_IssueBook", con);
                SqlCommand cmd2 = new SqlCommand("sp_GetIssuedBooks", con);


                cmd.Parameters.Add("@id_user", SqlDbType.Int).Value = userID;
                cmd.Parameters.Add("@id_book", SqlDbType.Int).Value = issuedBook.id;
                cmd.Parameters.Add("@issueDate", SqlDbType.VarChar).Value = DateTime.Now.ToString("yyyy/MM/dd");
                cmd.CommandType = CommandType.StoredProcedure;
                cmd2.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                SqlDataReader sdr = cmd2.ExecuteReader();

                while (sdr.Read())
                {

                    string book;
                    book = sdr["name_book"].ToString();

                    bookList.Add(book);

                }
                con.Close();
                return bookList;

            }

        }
        public void DeleteBook(string bookName)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_RemoveBook", con);



                cmd.Parameters.Add("@name_book", SqlDbType.VarChar).Value = bookName;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }

        }

        public void DeleteUser(int userId)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_RemoveUser", con);



                cmd.Parameters.Add("@id_user", SqlDbType.Int).Value = userId;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
        }
        public void ReturnBook(int bookId)
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_ReturnBook", con);



                cmd.Parameters.Add("@id_book", SqlDbType.Int).Value = bookId;
                

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();

            }
        }
        public DateTime GetIssueDate(int bookId)
        {
            DateTime issueDate = new DateTime();

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_IssueDate", con);



                cmd.Parameters.Add("@id_book", SqlDbType.Int).Value = bookId;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    issueDate = Convert.ToDateTime(sdr["issueDate"].ToString());
                }
                con.Close();

            }
            return issueDate;


        }
        // function created for validation whether book required issued or not
        public List<Book> GetIssuedBooks()
        {
            List<Book> bookList = new List<Book>();


            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_GetIssuedBooks", con);
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();

                while (sdr.Read())
                {

                    Book book=new Book();
                   
                    book.name = sdr["name_book"].ToString();
                    book.price = Convert.ToInt32(sdr["price_book"]);
                    book.id = Convert.ToInt32(sdr["id_book"]);
                    book.price = Convert.ToSingle(sdr["price_book"]);
                    book.shelfNo = Convert.ToInt32(sdr["shelfno_book"]);
                    book.category = sdr["category_book"].ToString();
                    bookList.Add(book);

                }
                con.Close();
                return bookList;
            }
        }
        // To get all the books
        // function created for validation of input
        // like updating or deleting the book
        public List<Book> GetAllBooks()
        {
            List<Book> bookList = new List<Book>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_GetAllBooks", con);

                cmd.CommandType = CommandType.StoredProcedure;

                con.Open();
             
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    Book bookStore = new Book();

                    bookStore.id = Convert.ToInt32(sdr["id_book"]);
                    bookStore.name = sdr["name_book"].ToString();
                    bookStore.price = Convert.ToInt32(sdr["price_book"]);
                    bookStore.shelfNo = Convert.ToInt32(sdr["shelfno_book"]);
                    bookStore.category = sdr["category_book"].ToString();


                    bookList.Add(bookStore);

                }

                con.Close();
                return bookList;

            }

        }

        // To get all users
        // function created for validation in the controller of input 
        // like updating or deleting the user
        public List<User> GetAllUsers()
        {
            List<User> usersList = new List<User>();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                
                SqlCommand cmd = new SqlCommand("sp_GetAllUsers", con);

                con.Open();
               
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {
                    User userStore = new User();

                    userStore.id = Convert.ToInt32(sdr["id_user"]);
                    userStore.name = sdr["name_user"].ToString();
                    usersList.Add(userStore);

                }
                con.Close();
                return usersList;

            }

        }

    }
 }

