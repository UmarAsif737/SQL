﻿using System.Collections.Generic;
using silachi.Models;
using System;
namespace silachi.DATA_Acces_Layer
{
    public interface ISQADataHelper
    {
     
            public List<Book> GetBook(string name);
            public List <Book> AddBook(Book book);
            public List<User> AddUser(User user);
            public User GetUser(int id);
            public void UpdateBook(Book updatedBook);
            public void  UpdateUser(User updatedUser);
            public List<string> IssueBook(int userID,Book updatedBook);
            public void DeleteBook(string bookName);
            public void DeleteUser(int userId);
            public void ReturnBook(int bookId);
            public DateTime GetIssueDate(int bookId);
            public List<Book> GetIssuedBooks();
            public List<User> GetAllUsers();

             public List<Book> GetAllBooks();






    }
}
