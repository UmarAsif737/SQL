﻿
using System.Collections.Generic;
using silachi.DATA_Acces_Layer;
using silachi.Models;
using System;
using System.Net;


namespace silachi.Business_Layer
{
    public class Library:ILibrary
    {
        ISQADataHelper _SQADataHelper;

        public Library(ISQADataHelper _SQADataHelper)
        {
           this._SQADataHelper = _SQADataHelper;
        }
        public List<Book> GetBook(string name)
        {
            return _SQADataHelper.GetBook(name);
        }
        public List<Book> AddBook(Book book)
        {
            return _SQADataHelper.AddBook(book);
            
        }
        public List<User> AddUser(User user)
        {
            return _SQADataHelper.AddUser(user);

        }

        public User GetUser(int id)
        {
            return _SQADataHelper.GetUser(id);
        }
        public void UpdateBook( Book updatedBook)
        {
           _SQADataHelper.UpdateBook(updatedBook);
        }
        public void UpdateUser(User updatedUser)
        {
            _SQADataHelper.UpdateUser(updatedUser);
        }
        public List<string> IssueBook(int userID, Book updatedBook)
        {
            return _SQADataHelper.IssueBook(userID, updatedBook);
        }
        public void DeleteBook(string bookName)
        {
            _SQADataHelper.DeleteBook(bookName);
        }
        public void DeleteUser(int userId)
        {
            _SQADataHelper.DeleteUser(userId);
        }
        public string ReturnBook(int bookId)
        {
            
            string returnDate = DateTime.Now.ToString("yyyy/MM/dd");
           string fine=CalculateFine(bookId, Convert.ToDateTime(returnDate));
            _SQADataHelper.ReturnBook(bookId);
            return fine;
        }
        public string CalculateFine(int bookId,DateTime inputDate)
        {
            DateTime checkDate = inputDate;
            DateTime issuedate = _SQADataHelper.GetIssueDate(bookId);
            int count = 0;
            for (DateTime i = issuedate; i <= checkDate; i = i.AddDays(1))
            {
               
                if (i.ToString("dddd") == "Sunday" || i.ToString("dddd") == "Saturday")
                {
                    continue;
                }
                count++;
            }

            //int store = Convert.ToInt32(returndate - issuedate);
            Console.WriteLine(count);
            if (count - 15 > 0)
            {
                return "Your Fine is Rs: " + (count - 15);
            }
            else
            {
                return "No fine imposed";

            }
        }
        public List<Book> GetIssuedBooks()
        {
            return _SQADataHelper.GetIssuedBooks();
        }


        public List<User> GetAllUsers()
        {
            return _SQADataHelper.GetAllUsers();
        }

        public List<Book> GetAllBooks()
        {
            return _SQADataHelper.GetAllBooks();
        }
    }
}
