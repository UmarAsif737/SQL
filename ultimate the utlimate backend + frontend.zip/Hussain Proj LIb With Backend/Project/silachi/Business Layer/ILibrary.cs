﻿using silachi.Models;
using System;
using System.Collections.Generic;

namespace silachi.Business_Layer
{
    public interface ILibrary
    {
        public List<Book> GetBook(string name);
        public List<Book> AddBook(Book book);
        public List<User> AddUser(User user);
        public User GetUser(int id);
        public void UpdateBook( Book updatedBook);
        public void UpdateUser(User updatedUser);
        public List<string> IssueBook(int userID, Book updatedBook);
        public void DeleteBook(string bookName);
        public void DeleteUser(int userId);
        public string ReturnBook(int bookId);
        public string CalculateFine(int bookId,DateTime inputDate);
        public List<Book> GetIssuedBooks();
        public List<User> GetAllUsers();

        public List<Book> GetAllBooks();




    }
}
