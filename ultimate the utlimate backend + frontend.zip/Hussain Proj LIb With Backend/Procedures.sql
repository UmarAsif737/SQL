use ProjLibrary

--Task 01
--Procedure Add Book to user
--description default value of price for new book 400 Rs if not assigned by user
-- default category fiction and default shelf no 2

CREATE PROCEDURE sp_AddBook

@name_book VARCHAR(30),
@price_book DECIMAL = 400,
@shelfno_book INT  = 2,
@category_book VARCHAR(30) = 'fiction'

AS
BEGIN
INSERT INTO BOOKS(name_book,price_book,shelfno_book,category_book)
VALUES
(@name_book, @price_book,@shelfno_book, @category_book)
END

--Task 02
--Procedure to add the user in users table
CREATE PROCEDURE sp_AddTheUser
@name_user VARCHAR(30)
AS
BEGIN
INSERT INTO Users
VALUES
(@name_user);
END

--Task 03
--Procedure to get detail of a book
CREATE PROCEDURE sp_GetBookDetails
@name_book VARCHAR(30)
AS
BEGIN
SELECT * FROM BOOKS WHERE name_book=@name_book;
END

--Task 04
--Procedure to get detials of a user
CREATE PROCEDURE sp_GetUser
@id_user INT
AS
BEGIN
SELECT * FROM Users WHERE id_user=@id_user
SELECT * FROM Books WHERE id_user=@id_user;
END

--Task 05
--Procedure to update detial of a book

CREATE PROCEDURE sp_UpdateBook
@id_book INT,
@name_book VARCHAR(30),
@price_book DECIMAL,
@shelfno_book INT,
@category_book VARCHAR
AS
BEGIN
UPDATE Books
SET name_book=@name_book, price_book=@price_book,shelfno_book=@shelfno_book,category_book=@category_book
WHERE id_book=@id_book
END

--Task 06
--Procedure to udpate user
CREATE PROCEDURE sp_UpdateUser
@id_user INT,
@name_user VARCHAR(30)
AS
BEGIN
UPDATE USERS
SET name_user=@name_user
WHERE id_user=@id_user
END

--Task 07
--Procedure to Issue book 
CREATE PROCEDURE sp_IssueBook

@id_book INT,
@id_user INT,
@issueDate Date
AS
BEGIN
IF EXISTS (SELECT * FROM BOOKS WHERE id_book=@id_book AND id_user is NULL)
BEGIN     
UPDATE BOOKS SET id_user=@id_user, issueDate=@issueDate WHERE id_book=@id_book;
END

END


--Task 08
--Procedure to remove book from library and delete record of user
CREATE PROCEDURE sp_RemoveBook
@name_book VARCHAR(30)
AS
BEGIN
DELETE FROM BOOKS WHERE name_book = @name_book;
END

--Task 09
--user will be removed if he has no issued books
CREATE PROCEDURE sp_RemoveUser
@id_user INT
AS
BEGIN
IF NOT EXISTS (select * from BOOKS WHERE id_user=@id_user)
BEGIN
DELETE Users WHERE id_user =  @id_user
END
END

select * from users


--Task 10
--Procedure to return the book
CREATE PROCEDURE sp_ReturnBook
@id_book INT

AS
BEGIN
 UPDATE BOOKS SET id_user = NULL,issueDate=NULL WHERE id_book=@id_book
END


--Task 11
--To get issue date of particular book
CREATE PROCEDURE sp_IssueDate
@id_book INT
AS
BEGIN
SELECT issueDate FROM BOOKS WHERE id_book = @id_book
END


--Procedures to show changes in tables after user action
--and validation before updating some record

--GetAllBooks
CREATE PROCEDURE sp_GetAllBooks
AS
BEGIN
SELECT * FROM BOOKS
END

--GetAllUsers
CREATE PROCEDURE sp_GetAllUsers
AS
BEGIN
SELECT name_user,id_user FROM Users

END
select * from Users
select * from Books

--GetIssuedBooks
CREATE PROCEDURE sp_GetIssuedBooks
AS
BEGIN
SELECT * FROM Books WHERE id_user is not null
END




